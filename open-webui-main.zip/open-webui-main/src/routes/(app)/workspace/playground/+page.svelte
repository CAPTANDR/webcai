<script>
	import Playground from '$lib/components/workspace/Playground.svelte';
</script>

<Playground />
