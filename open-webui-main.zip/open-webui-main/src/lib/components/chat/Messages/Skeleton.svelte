<div class="w-full mt-2 mb-4">
	<div class="animate-pulse flex w-full">
		<div class="space-y-2 w-full">
			<div class="h-2 bg-gray-200 dark:bg-gray-600 rounded mr-14" />

			<div class="grid grid-cols-3 gap-4">
				<div class="h-2 bg-gray-200 dark:bg-gray-600 rounded col-span-2" />
				<div class="h-2 bg-gray-200 dark:bg-gray-600 rounded col-span-1" />
			</div>
			<div class="grid grid-cols-4 gap-4">
				<div class="h-2 bg-gray-200 dark:bg-gray-600 rounded col-span-1" />
				<div class="h-2 bg-gray-200 dark:bg-gray-600 rounded col-span-2" />
				<div class="h-2 bg-gray-200 dark:bg-gray-600 rounded col-span-1 mr-4" />
			</div>

			<div class="h-2 bg-gray-200 dark:bg-gray-600 rounded" />
		</div>
	</div>
</div>
