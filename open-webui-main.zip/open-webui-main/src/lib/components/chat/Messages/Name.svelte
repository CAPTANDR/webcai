<div class=" self-center font-bold mb-0.5 line-clamp-1 contents">
	<slot />
</div>
